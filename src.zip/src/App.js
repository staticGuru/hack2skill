import { Route, Router } from "react-router-dom";
import "./App.css";
import SignUp from "./screen/SignUp";

function App() {
  return (
      <div className="App">
        <SignUp />
      </div>
  );
}

export default App;
