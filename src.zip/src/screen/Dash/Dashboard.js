import React from 'react'

function Dashboard() {
  return (
    <div>
      <p>guruvignesh</p>
    </div>
  )
}

export default Dashboard
